from flask import Flask, render_template, Response, request, redirect, url_for, session,flash,make_response
import io
import cv2
import os
import pickle
import datetime
import shutil
from mysql import connector
import face_recognition as fr
from flask_mail import Mail, Message
import pymysql

pymysql.install_as_MySQLdb()
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)
app.config.update(
    DEBUG=True,
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=587,
    MAIL_USE_SSL=False,
    MAIL_USE_TLS=True,
    MAIL_USERNAME='darshan.parvam@gmail.com',
    MAIL_PASSWORD='bpnkvvoytfowsxze'
)
app.secret_key = "amanfromsvitcollege"
mail = Mail(app)
mydb = connector.connect(host="localhost", user="root", passwd="", port=3306, database="automatedattendance", charset='latin1')
mycursor = mydb.cursor()

# Function to get the current location
def get_location():
    try:
        response = requests.get('http://ip-api.com/json/')
        data = response.json()
        if data['status'] == 'fail':
            raise Exception('Failed to fetch location')
        return data  # Returns latitude and longitude along with other details
    except Exception as e:
        print(f"Error fetching location: {e}")
        return None

vc = cv2.VideoCapture(0)
current_date = datetime.datetime.now().strftime('%Y-%m-%d')

with open('trainedmodels/student_names.pkl', 'rb') as f:
    student_names = pickle.load(f)
with open('trainedmodels/face_encoding_data.pkl', 'rb') as f:
    face_encoding_data = pickle.load(f)

@app.route('/')
def index():
    return render_template('index.html')
import requests

def gen():
    print("00000000000000000000000000000000000000000000")
    process_this_frame = True
    while True:
        read_return_code, frame = vc.read()
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = small_frame[:, :, ::-1]

        if process_this_frame:
            face_locations = fr.face_locations(rgb_small_frame)
            face_encodings = fr.face_encodings(rgb_small_frame, face_locations)
            face_names = []

            try:
                for face_encoding in face_encodings:
                    matches = fr.compare_faces(face_encoding_data, face_encoding)
                    if True in matches:
                        first_match_index = matches.index(True)
                        name = student_names[first_match_index]
                        face_names.append(name)

                        # Get location
                        location = get_location()
                        if location:
                            # Print the location details
                            print(f"City: {location.get('city')}")
                            print(f"State: {location.get('regionName')}")
                            print(f"Country: {location.get('country')}")
                            print(f"Latitude: {location.get('lat')}")
                            print(f"Longitude: {location.get('lon')}")
                            # Print location data

                            # Check if attendance needs to be updated
                            sql = "SELECT * FROM attendance WHERE student_id=(SELECT id FROM studentregisteration WHERE uname=%s) AND login=%s"
                            mycursor.execute(sql, (name, current_date))
                            myresult = mycursor.fetchall()
                            print("1111111111111111111111111111111111111111")
                            if len(myresult) < 1:
                                print("2222222222222222222222222222222222222")
                                try:
                                    # Insert new attendance record
                                    now = datetime.datetime.now()
                                    print("33333333333333333333333333333333333333")
                                    timestamp = now.strftime('%Y-%m-%d %H:%M:%S')
                                    sql = "INSERT INTO attendance(student_id, login) VALUES((SELECT id FROM studentregisteration WHERE uname=%s), %s)"
                                    val = (name, current_date)
                                    mycursor.execute(sql, val)
                                    mydb.commit()
                                    return None
                                except Exception as e:
                                    print(f"Error: {e}")
                            print("44444444444444444444444444444444444")
                # Flash a success message
                flash("Attendance updated successfully!")
                return redirect(url_for('index'))  # Redirect to the index page
            except Exception as e:
                print(f"Error: {e}")

        process_this_frame = not process_this_frame

        for (top, right, bottom, left), name in zip(face_locations, face_names):
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

        encode_return_code, image_buffer = cv2.imencode('.jpg', frame)
        io_buf = io.BytesIO(image_buffer)
        yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + io_buf.read() + b'\r\n')

@app.route('/video_feed')
def video_feed():
    return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')

def gen_register():
    while True:
        read_return_code, frame = vc.read()
        encode_return_code, image_buffer = cv2.imencode('.jpg', frame)
        io_buf = io.BytesIO(image_buffer)
        yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + io_buf.read() + b'\r\n')

@app.route('/register_feed')
def register_feed():
    return Response(gen_register(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/captureimage')
def captureimage():
    if 'user' not in session:
        return redirect('/')
    read_return_code, frame = vc.read()
    shutil.rmtree('static/temp')
    os.mkdir('static/temp')
    img_path = 'static/temp/' + str(datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')) + '.jpg'
    cv2.imwrite(img_path, frame)
    try:
        person_identified = fr.face_encodings(fr.load_image_file(img_path))[0]
        if len(person_identified) > 0:
            return img_path
        else:
            return 'static/error_face.jpg'
    except:
        return 'static/error_face.jpg'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            userdetails = request.form
            sql = "SELECT * FROM user WHERE username=%s AND password=%s"
            mycursor.execute(sql, (userdetails['name'], userdetails['password']))
            myresult = mycursor.fetchone()
            if myresult:
                session['user'] = myresult[0]
                return redirect(url_for('adminpanel'))
        except Exception as e:
            print(f"Error: {e}")
    return render_template('login.html', message="Invalid Username or password")

@app.route('/adminpanel', methods=['GET', 'POST'])
def adminpanel():
    if 'user' not in session:
        return redirect('/')
    mycursor.execute("SELECT * FROM studentregisteration;")
    myresult = mycursor.fetchall()
    print(myresult)
    mycursor.execute("SELECT sr.id FROM studentregisteration sr, attendance a WHERE sr.id = a.student_id AND login = %s", (current_date,))
    today_attendance = mycursor.fetchall()
    today_attendance = [a[0] for a in today_attendance]
    if 'message' in session:
        message = session['message']
        session.pop('message', None)
        return render_template('dashboard.html', adminpanel=myresult, attendance=today_attendance, message=message)
    return render_template('dashboard.html', adminpanel=myresult, attendance=today_attendance)

import datetime

@app.route('/sendMail/<id>')
def sendMail(id):
    if 'user' not in session:
        return redirect('/')

    try:
        # Get the current date
        current_date = datetime.datetime.now().strftime('%Y-%m-%d')
        print(current_date)
        # SQL query to fetch student details
        sql = "SELECT * FROM studentregisteration WHERE id=%s"
        mycursor.execute(sql, (id,))
        myresult = mycursor.fetchall()
        print(myresult)

        if not myresult:
            session['message'] = 'Student not found'
            return redirect(url_for('adminpanel'))

        student_info = myresult[0]
        print(str(student_info[4]))
        # Prepare the email
        msg = Message(
            "Attendance Status: SVIT college",
            sender="darshan.parvam@gmail.com",  # Ensure this is the same as your MAIL_USERNAME
            recipients=[str(student_info[4])]
        )

        msg.html = f"""
        <h1>ParvaM Software Solution.Pvt</h1>
        <h2>Attendance Report: </h2><br>
        <h3>Student Name: {student_info[1]}</h3>
        <h3>Absent Date: {current_date}</h3>
        <p>Parents are requested to provide a valid reason for the absence if it is not due to illness, injury, medical appointment, approved educational activity, or religious/cultural ceremony.</p><br>
        <h4>Thank you</h4>
        """

        # Send the email
        mail.send(msg)
        session['message'] = 'Mail sent'
        return redirect(url_for('adminpanel'))

    except Exception as e:
        # Log the exception for debugging purposes (optional)
        print(f"Error sending email: {e}")
        session['message'] = 'Unable to Send Mail'
        return redirect(url_for('adminpanel'))


@app.route('/showattendance/<id>')
def showattendance(id):
    if 'user' not in session:
        return redirect('/')
    mycursor = mydb.cursor()
    sql = "SELECT @a:=@a+1 serial_number, login FROM attendance, (SELECT @a:= 0) AS a WHERE student_id=%s"
    mycursor.execute(sql, (id,))
    myresult = mycursor.fetchall()
    return render_template('studentattendance.html', studentattendance=myresult)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user' not in session:
        return redirect('/')
    if request.method == 'POST':
        try:
            userdetails = request.form
            shutil.move(userdetails['imagepath'], 'static/studentimages')
            file_path = os.path.join('static/studentimages', os.path.basename(userdetails['imagepath']))

            sql = "INSERT INTO studentregisteration(uname, upic, phone, email, usn, addr) VALUES (%s, %s, %s, %s, %s, %s)"
            val = (userdetails['uname'], file_path, userdetails['phone'], userdetails['email'], userdetails['usn'], userdetails['addr'])
            mycursor.execute(sql, val)
            mydb.commit()
            mycursor.execute("SELECT uname, upic FROM studentregisteration")
            myresult = mycursor.fetchall()

            face_encoding_data.clear()
            student_names.clear()

            for data in myresult:
                student_names.append(data[0])
                face_encoding_data.append(fr.face_encodings(fr.load_image_file(data[1]))[0])

            with open('trainedmodels/student_names.pkl', 'wb') as f:
                pickle.dump(student_names, f)
            with open('trainedmodels/face_encoding_data.pkl', 'wb') as f:
                pickle.dump(face_encoding_data, f)

            return render_template('register.html', message='success')
        except Exception as e:
            print(e)
            return render_template('register.html')
    return render_template('register.html')

@app.route('/generatereport', methods=['GET', 'POST'])
def generatereport():
    if 'user' not in session:
        return redirect('/')
    if request.method == 'POST':
        try:
            userdetails = request.form
            fromdate = request.form.get('fromdate', '')  # Get from POST or default to an empty string
            todate = request.form.get('todate', '')
            sql = "SELECT @a:=@a+1 serial_number, uname, login FROM attendance ac, studentregisteration sr, (SELECT @a:= 0) AS a WHERE sr.id = ac.student_id AND login >= %s AND login <= %s ORDER BY login ASC"
            mycursor.execute(sql, (userdetails['fromdate'], userdetails['todate']))
            myresult = mycursor.fetchall()
            return render_template('reports.html', attendance=myresult,fromdate=fromdate, todate=todate)
        except Exception as e:
            print(f"Error: {e}")
            flash("Error generating report")
    return render_template('reports.html')


def get_attendance_report(from_date, to_date):

    sql = """
        SELECT @a:=@a+1 AS serial_number, 
               sr.uname, 
               ac.login 
        FROM attendance ac
        JOIN studentregisteration sr ON sr.id = ac.student_id
        JOIN (SELECT @a:= 0) AS a
        WHERE ac.login >= %s AND ac.login <= %s
        ORDER BY ac.login ASC;
    """

    mycursor.execute(sql, (from_date, to_date))
    results = mycursor.fetchall()
    return results


@app.route('/download_report', methods=['POST'])
def download_report():
    from_date = request.form['fromdate']
    to_date = request.form['todate']

    attendance_data = get_attendance_report(from_date, to_date)

    output = [['Sl no.', 'Student Name', 'Present on']]
    output.extend(attendance_data)

    response = make_response('\n'.join([','.join(map(str, row)) for row in output]))
    response.headers['Content-Disposition'] = 'attachment; filename=attendance_report.csv'
    response.headers['Content-Type'] = 'text/csv'

    return response


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('user', None)
    return render_template('index.html')

@app.route('/location', methods=['GET'])
def location():
    return render_template('Geolocation.html')

# @app.route('/update_location', methods=['POST'])
# def update_location():
#     try:
#         # Get JSON data from the request
#         data = request.get_json()
#         latitude = data.get('latitude')
#         longitude = data.get('longitude')
#         # Get the current date and time
#         now = datetime.datetime.now()
#         timestamp = now.strftime('%Y-%m-%d %H:%M:%S')  # Format the timestamp
#         student_id =  # Get student_id from the request
#
#         # Validate data
#         if not latitude or not longitude or not student_id:
#             return {"message": "Missing required fields"}, 400
#
#         # Update location data in the database
#         sql = "UPDATE attendance SET latitude = %s, longitude = %s, time=%s WHERE student_id = %s AND login = %s"
#         mycursor.execute(sql, (latitude, longitude, timestamp, student_id, current_date))
#         mydb.commit()
#
#         return {"message": "Location updated successfully"}, 200
#
#
#     except Exception as e:
#
#         print("Error:", e)
#
#         traceback.print_exc()  # This will give you a full traceback
#
#         return {"message": "An error occurred while updating location"}, 500

if __name__ == '__main__':
    app.run(debug=True, threaded=True)